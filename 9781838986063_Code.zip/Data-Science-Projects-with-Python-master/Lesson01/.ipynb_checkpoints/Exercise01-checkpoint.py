for counter in range(5):
...    print(counter)
... 
example_dict = {'apples':5, 'oranges':8, 'bananas':13}
dict_to_list = list(example_dict)
dict_to_list
dict_to_list = dict_to_list + ['pears']
dict_to_list
sorted(dict_to_list)
